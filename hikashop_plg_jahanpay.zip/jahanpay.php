﻿<?php
/**
 * @package	HikaShop for Joomla!
 * @version	2.2.3
 * @author	hikashop.com
 * @copyright	(C) 2010-2013 HIKARI SOFTWARE. All rights reserved.
 * @license	GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */
 
defined('_JEXEC') or die('Restricted access');



?><?php
class plgHikashoppaymentjahanpay extends hikashopPaymentPlugin
{
	var $accepted_currencies = array(
		'AUD','BRL','CAD','EUR','GBP','JPY','USD','NZD','CHF','HKD','SGD','SEK',
		'DKK','PLN','NOK','HUF','CZK','MXN','MYR','PHP','TWD','THB','ILS','TRY','IRR'
	);

	var $multiple = true;
	var $name = 'jahanpay';
	var $doc_form = 'jahanpay';

	function __construct(&$subject, $config) {
		parent::__construct($subject, $config);
		
	}

	function onBeforeOrderCreate(&$order,&$do){
	
		if(parent::onBeforeOrderCreate($order, $do) === true)
			return true;
	}

	function onAfterOrderConfirm(&$order, &$methods, $method_id) {
		parent::onAfterOrderConfirm($order, $methods, $method_id);
		
		if($this->currency->currency_locale['int_frac_digits'] > 2)
			$this->currency->currency_locale['int_frac_digits'] = 2;
			
		$pluginsClass = hikashop_get('class.plugins');
		$elements = $pluginsClass->getMethods('payment','jahanpay');
		$element = reset($elements);
		
		$mainframe = jfactory::getapplication();
		

		$amount = (int)$order->order_full_price;
		$return = HIKASHOP_LIVE.'index.php?option=com_hikashop&ctrl=checkout&task=notify&notif_payment='.$element->payment_type.'&tmpl=component&lang='.$this->locale . $this->url_itemid."&orderid=".$order->order_id."&amount=".$amount;

		$client = new SoapClient("http://www.jpws.me/directservice?wsdl");
		$api = $element->payment_params->merchant;
		$amount =  $amount / 10; //Tooman
		$callbackUrl = $return;
		$orderId = $order->order_id;

		// echo "<pre>";
		// print_r(array($api ,$amount ,$callbackUrl ,$orderId ,$txt));
		// exit;
		 
		$res = $client->requestpayment($api, $amount, $callbackUrl, $orderId);	
		if($res['result']==1){
		session_start();
		$_SESSION['jp_au']=$res['au'];
	 echo ('<div style="display:none;">'.$res['form'].'</div><script>document.forms["jahanpay"].submit();</script>');
		
		}else{
		
			$url = HIKASHOP_LIVE."index.php?option=com_hikashop&ctrl=checkout";
			$mess .= 'خطا در اتصال به درگاه'."<br>";
			$mess .= $res['result'];
			$app = jfactory::getapplication();
			$app->redirect($url,$mess);			
		
		}
	}

	function onPaymentNotification(&$statuses) {
		
		$pluginsClass = hikashop_get('class.plugins');
		$elements = $pluginsClass->getMethods('payment','jahanpay');
		$element = reset($elements);	

		$order_id = jRequest::getVar('orderid');
		
		$dbOrder = $this->getOrder((int)$order_id);
		$this->loadPaymentParams($dbOrder);
		if(empty($this->payment_params))
			return false;
		$this->loadOrderData($dbOrder);

		if(!$this->payment_params->notification)
			return false;
		if($this->payment_params->debug)
			echo print_r($vars, true) . "\r\n\r\n";
		if(empty($dbOrder)) {
			echo 'Could not load any order for your notification ' . @$vars['invoice'];
			return false;
		}	
		
		$url = HIKASHOP_LIVE."index.php?option=com_hikashop&ctrl=order&task=show&cid=$order_id";
		$order_text = "\r\n" . JText::sprintf('NOTIFICATION_OF_ORDER_ON_WEBSITE', $dbOrder->order_number, HIKASHOP_LIVE);
		$order_text .= "\r\n" . str_replace('<br/>', "\r\n", JText::sprintf('ACCESS_ORDER_WITH_LINK', $url));
		$ip = hikashop_getIP();
		$ips = str_replace(array('.', '*', ','), array('\.', '[0-9]+', '|'), $this->payment_params->ips);
		
		
		
		$errorCode = array(
			-1=>'api نامعتبر است' ,
			-2=>'مبلغ از کف تعریف شده کمتر است' ,
			-3=>'مبلغ از سقف تعریف شده بیشتر است' ,
			-4=>'مبلغ نامعتبر است' ,
			-6=>'درگاه غیرفعال است' ,
			-7=>'آی پی شما مسدود است' ,
			-9=>'آدرس کال بک خالی است ' ,
			-10=>'چنین تراکنشی یافت نشد' ,
			-11=>'تراکنش انجام نشده ' ,
			-12=>'تراکنش انجام شده اما مبلغ نادرست است ' ,
			//1 => "تراکنش با موفقیت انجام شده است " ,
		);		
		$api = $element->payment_params->merchant;
		$amount = $_GET['amount']/10; //Tooman
		session_start();
		$au=$_SESSION['jp_au'];
		$client = new SoapClient("http://www.jpws.me/directservice?wsdl");
         $result = $client->verification($api , $amount , $au , $_GET["orderid"], $_POST + $_GET );

		if( ! empty($result['result']) and $result['result'] == 1){
			$history = new stdClass();
			$email = new stdClass();
			$history->notified = 1;
			$history->order_invoice_number = $au;
			$history->data = '<div class="red">پرداخت با موفقیت انجام شد'.'<br>شناسه پرداخت:'.$au."</div>";
			$payment_status = 'Accepted';
			$email->body = str_replace('<br/>',"\r\n",JText::sprintf('PAYMENT_NOTIFICATION_STATUS','jahanpay', $payment_status)).' '.JText::sprintf('ORDER_STATUS_CHANGED', $statuses[$order_status])."\r\n\r\n".$order_text;
			$email->subject = JText::sprintf('PAYMENT_NOTIFICATION_FOR_ORDER', 'jahanpay', $payment_status, $dbOrder->order_number);	
			$cartClass = hikashop_get('class.cart');
			$cartClass->resetCart();
			$order_status = $this->payment_params->verified_status;
			$this->modifyOrder($order_id, $order_status, $history, $email);
			// jfactory::getSession()->set( 'hika_c_orderid', $_POST['order_id'] );	
			// jfactory::getSession()->set( 'hika_c_referenceid', $InvoiceNumber );	
			$app = jfactory::getapplication();
			$app->redirect($url,$history->data);			
		}
		else{
			
			$url = HIKASHOP_LIVE."index.php?option=com_hikashop&ctrl=checkout";
			$mess .= 'کاربر منصرف شده است'."<br>";
			$mess .= $result['result'];
			$app = jfactory::getapplication();
			$app->redirect($url,$mess);					
			
		}		
		
		
	}
	
	
	function onPaymentConfiguration(&$element) {
		$subtask = JRequest::getCmd('subtask', '');
		if($subtask == 'ips') {
			$ips = null;
			echo implode(',', $this->_getIPList($ips));
			exit;
		}

		parent::onPaymentConfiguration($element);
		$this->address = hikashop_get('type.address');


	}

	function onPaymentConfigurationSave(&$element) {
		if(!empty($element->payment_params->ips))
			$element->payment_params->ips = explode(',', $element->payment_params->ips);
		return true;
	}

	function getPaymentDefaultValues(&$element) {
		$element->payment_name = 'jahanpay';
		$element->payment_description='You can pay by credit card or jahanpay using this payment method';
		$element->payment_images = 'MasterCard,VISA,Credit_card,jahanpay';

		$element->payment_params->url = 'https://www.jahanpay.me';
		$element->payment_params->notification = 1;
		$element->payment_params->ips = '';
		$element->payment_params->details = 0;
		$element->payment_params->invalid_status = 'cancelled';
		$element->payment_params->pending_status = 'created';
		$element->payment_params->verified_status = 'confirmed';
		$element->payment_params->address_override = 1;
	}

	function _getIPList(&$ipList) {
		$hosts = array(
			'www.jahanpay.com',
			'notify.jahanpay.com',
			'ipn.sandbox.jahanpay.com'
		);

		$ipList = array();
		foreach($hosts as $host) {
			$ips = gethostbynamel($host);
			if(!empty($ips)) {
				if(empty($ipList))
					$ipList = $ips;
				else
					$ipList = array_merge($ipList, $ips);
			}
		}

		if(empty($ipList))
			return $ipList;

		$newList = array();
		foreach($ipList as $k => $ip) {
		$ipParts = explode('.', $ip);
		if(count($ipParts) == 4) {
			array_pop($ipParts);
			$ip = implode('.', $ipParts) . '.*';
		}
		if(!in_array($ip, $newList))
			$newList[] = $ip;
		}
		return $newList;
	}
}
